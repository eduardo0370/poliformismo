
package herancapoliformismo;

public class HerancaPoliformismo {
    
    public void blablabla(OperacaoMatematica op, double x, double y){
        op.Calcular(x, y);
    }

 
    public static void main(String[] args) {
        Soma s = new Soma();
        s.Calcular(10, 20);
              
    }
    
}
