
package herancapoliformismo;

import static java.time.Clock.system;


public class OperacaoMatematica {
    public void Calcular(double valorUm, double valorDois){
        System.out.println("NAO REALIZA NENHUMA OPERACAO");
    }
    
}
