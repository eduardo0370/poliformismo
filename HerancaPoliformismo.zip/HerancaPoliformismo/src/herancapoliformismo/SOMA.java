
package herancapoliformismo;


public class SOMA extends OperacaoMatematica{
    
    @Override
    public void Calcular(double valorUm, double valorDois){
        double resultado = valorUm + valorDois;
        System.out.println("O VALOR DA SOMA É:" + resultado);
                
    }
    
}
